M2.5
Self tapping screws
pan head type
Thread lenght = 3mm - 4mm
QTY (x2)

M1.5
Self tapping screws
pan head type
Thread lenght = 4mm - 6mm
QTY (x4)